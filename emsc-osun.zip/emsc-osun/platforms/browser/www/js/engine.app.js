!function($) {
    "use strict";

    //FORMS NO SUBMIT ACTION
	jQuery(".no-submit").submit(function(){return false});

    //DECLARE BOOTSTRAP TOOLTIPS
    jQuery('[data-toggle="tooltip"]').tooltip();

	//VALIDATE EMAIL
	function is_email(email){      
		var emailReg = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		return emailReg.test(email); 
	}
	//VALIDATE INPUT DIGIT
	function is_digits(number){      
		var numberReg = /^[\d\,\.]*$/;
		return numberReg.test(number); 
	}

	//RANDOM TOKEN GENERATOR
	function randomString(length, chars){
		var result = '';
		for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
		return result;
	}

    //ADD COMMAS TO CURRENCY
    jQuery.fn.digits = function(){
        return this.each(function(){ 
            $(this).text( $(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
        })
    }
    
    //LOGIN PAGE FORM SUBMIT FUNCTION
    jQuery(document).on("click", "#btn-login", function(){
        //SET BUTTON LOADING STATE
        jQuery("#btn-login").addClass("disabled");
        jQuery("#btn-login").addClass("ng-loading");

        //VALIDATE FIELDS > LOGIN USERNAME
        if(jQuery("#inputUsername").val().length<3){
            //SET BUTTON DEFAULT STATE
            jQuery("#btn-login").removeClass("disabled");
            jQuery("#btn-login").removeClass("ng-loading");
            //ALERT ERROR
            swal("Invalid Username!", "Please enter your username.", "warning");
        }
        //VALIDATE FIELDS > LOGIN PASSWORD
        else if(jQuery("#inputPass").val().length<3){
            //SET BUTTON DEFAULT STATE
            jQuery("#btn-login").removeClass("disabled");
            jQuery("#btn-login").removeClass("ng-loading");
            //ALERT ERROR
            swal("Invalid Password!", "Please enter your password.", "warning");
        }
        else{
			//REDIRECT TO HOME PAGE
			window.location.href = "home.html";
			/*
            //POST DETAILS TO SERVER
            jQuery.ajax({
                url: "assets/api/post/login",
                type: 'POST',
                data: {
                    user: jQuery("#inputUsername").val(),
                    pass: jQuery("#inputPass").val()
                },
                success: function(data){
                    data = data.split('#');
                    status = data[0];
                    data = data[1];
                    //CHECK RESPONSE STATUS > IF FAIL ALERT ERROR MESSAGE
                    if(status == 'fail'){
                        //SET BUTTON DEFAULT STATE
                        jQuery("#btn-login").removeClass("disabled");
                        jQuery("#btn-login").removeClass("ng-loading");
                        //ALERT ERROR
                        swal({   
                            title: "Oops! Something went wrong.",   
                            text: data,
                            type: "error"
                         });
                    }
                    //ELSE PERFORM SUCCESS EVENT
                    else{
                        //REDIRECT TO HOME PAGE
                        window.location.href = "home.html";
                    }
                },
                error: function(){
                    //SET BUTTON DEFAULT STATE
                    jQuery("#btn-login").removeClass("disabled");
                    jQuery("#btn-login").removeClass("ng-loading");
                    //ALERT ERROR
                    swal({   
                        title: "Oops! Something went wrong.",   
                        text: "We could not reach OsusuMobile HQ. Please check your Internet connection and try again.",
                        type: "error"
                    });
                }
            });
			
			*/
        }
    });
	
	//NO INDICATORS AVAILABLE > HOME PAGE
    jQuery(document).on("click", ".btn-na", function(){
		//ALERT ERROR
		swal({   
			title: "Sorry! No Indicators.",   
			text: "Sadly there are no indicators for this module. please select another module.",
			type: "error"
		});
	});


    //SUBMIT INDICATOR FORMS FUNCTION
    jQuery(document).on("click", "#getstarted_btn_submit", function(){

        //SET BUTTON LOADING STATE
        jQuery("#getstarted_btn_submit").addClass("disabled");
        jQuery("#getstarted_btn_submit").addClass("ng-loading");

        //VALIDATE FIELDS > TEXT FIELD
        if(jQuery("#getstarted_text_f").val().length<2){
            //SET BUTTON DEFAULT STATE
            jQuery("#getstarted_btn_submit").removeClass("disabled");
            jQuery("#getstarted_btn_submit").removeClass("ng-loading");
            //ALERT ERROR
            swal("Invalid Text Field!", "Please enter some text.", "warning");
        }
        //VALIDATE FIELDS > TEXT AREA
        else if(jQuery("#getstarted_area").val().length<2){
            //SET BUTTON DEFAULT STATE
            jQuery("#getstarted_btn_submit").removeClass("disabled");
            jQuery("#getstarted_btn_submit").removeClass("ng-loading");
            //ALERT ERROR
            swal("Invalid Text Area!", "Please enter some text.", "warning");
        }
		 //VALIDATE FIELDS > FIGURES
        else if(jQuery("#getstarted_figures").val()==""){
            //SET BUTTON DEFAULT STATE
            jQuery("#getstarted_btn_submit").removeClass("disabled");
            jQuery("#getstarted_btn_submit").removeClass("ng-loading");
            //ALERT ERROR
            swal("Invalid Figures!", "Please enter some numbers.", "warning");
        }
        else{
			
            //CONFIRM ACTION
            swal({
                title: "Submit Form",
                text: "Are you sure you want to submit this form data?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#39c480",
                confirmButtonText: "Yes, submit form!",
                closeOnConfirm: false
            },
            function(isConfirm){
                if (isConfirm) {
                    //
                    swal({
                        title: "Submitting",   
                        text: "Just a sec, processing...",
                        html: true,
                        showConfirmButton: false
                     });

                    //POST DETAILS TO SERVER
                    jQuery.ajax({
                        url: "http://demos.osusumobile.com/thinkhat/emsc/dashboard/api/post/form.php",
                        type: 'POST',
                        data: {
                            text_field: jQuery("#getstarted_text_f").val(),
                            text_area: jQuery("#getstarted_area").val(),
                            text_tf: jQuery( "input[type=radio][name=inlineRadioOptions]:checked" ).val(),
                            text_figures: jQuery("#getstarted_figures").val(),
							text_form_id: jQuery("#form_id").val()
                        },
                        success: function(data){
                            data = data.split('#');
                            status = data[0];
                            data = data[1];
                            //CHECK RESPONSE STATUS > IF FAIL ALERT ERROR MESSAGE
                            if(status == 'fail'){
                                //SET BUTTON DEFAULT STATE
                                jQuery("#getstarted_btn_submit").removeClass("disabled");
								jQuery("#getstarted_btn_submit").removeClass("ng-loading");
                                //ALERT ERROR
                                swal({   
                                    title: "Whoops! Something went wrong.",   
                                    text: data,
                                    type: "error"
                                 });
                            }
                            //ELSE PERFORM SUCCESS EVENT
                            else{
                                //
								swal({
									title: "Form Submitted!",   
									text: data,
									type: "success",
									showConfirmButton: false
								});
								//
								setTimeout(function(){ window.location.href = "home.html" }, 7000);
                            }
                        },
                        error: function(){
                            //SET BUTTON DEFAULT STATE
                            jQuery("#getstarted_btn_submit").removeClass("disabled");
							jQuery("#getstarted_btn_submit").removeClass("ng-loading");
                            //ALERT ERROR
                            swal({   
                                title: "Whoops! No Internet Access.",   
                                text: "Please save this form and try to submit later.",
                                type: "error"
                            });
                        }
                    });
                }
                else{
                    //SET BUTTON DEFAULT STATE
                    jQuery("#getstarted_btn_submit").removeClass("disabled");
					jQuery("#getstarted_btn_submit").removeClass("ng-loading");
                }

            });
        }
    });
	


    //CHECK IF PAGE IS START > 
    if(document.getElementById('current_page_start')){
        
        //GET PIN CONFIRMED > CHECK IF PIN CONFIRMED IS 1
        if(jQuery("#user_pin_confirm").val() == 1){
            //REMOVE LOADING ICON & SHOW SUCCESS ICON
            jQuery(".page-activate").addClass("success");
            jQuery(".activate-icon").html("<i class='pe-7s-check'></i>");
            //SET SUCCESS MESSAGE
            jQuery(".activate-text").html("Saver's profile successfully created.");
            jQuery(".showActivated").show();
        }
        else{
            
        }

    }

    //CREATE SAVER PROFILE FORM SUBMIT FUNCTION
    jQuery(document).on("click", ".btn-save-q", function(){
		
        //SET BUTTON LOADING STATE
        jQuery(".btn-save-q").addClass("disabled");
        jQuery(".btn-save-q").addClass("ng-loading");
		
		//
		swal({   
			title: "Form Saved!",   
			text: "Your Form has been successfully saved. You can return to it at any time. Please wait while we redirect you back home...",
			type: "success",
			showConfirmButton: false
		});
		//
		setTimeout(function(){ window.location.href = "home.html" }, 7000);
		
	});

}(window.jQuery);